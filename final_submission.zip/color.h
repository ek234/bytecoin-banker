#ifndef __COLOR_H
#define __COLOR_H

#include <stdio.h>

void Bblack();
void black();
void red();
void green();
void yellow();
void blue();
void Bcyan();
void cyan();
void white();
void reset();

#endif
