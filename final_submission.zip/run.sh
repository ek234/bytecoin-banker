 #!/bin/bash    
 clear
 gcc  main.c bitcoin.c hash.c trans.c user.c update_val.c color.c -g -o iiitcoin.c.ex && ./iiitcoin.c.ex
